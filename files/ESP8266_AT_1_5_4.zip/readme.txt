******************************************************************
AiThinker_ESP8266_DIO_8M_8M_20160615_V1.5.4.bin

MD5: 8E9E9252317A9BCA67673C17B9E3E075

FirmWare Infomation:
    SPI MODE: DIO
    Flash Size: 8Mbit
    File Size: 8Mbit
    SPI SPEED: 40MHz
    SDK Version: V1.5.4
    Release Date: 2016.6.15
    
******************************************************************
AiThinker_ESP8266_DIO_32M_32M_20160615_V1.5.4.bin

MD5: B561B49242DC88EA5CBFCAB0CF287BF5

FirmWare Infomation:
    SPI MODE: DIO
    Flash Size: 32Mbit
    File Size: 32Mbit
    SPI SPEED: 40MHz
    SDK Version: V1.5.4
    Release Date: 2016.6.15
    
******************************************************************

How to download:
    1. Please select the firmware in ESP_DOWNLOAD_TOOL_V2.4;
    2. The address should write 0x00000;
    3. If you don't know how to config your download panel, please checked the "DoNotChgBin". That will be download the bin as default setting.

    
    More infomation please visit http://www.ai-thinker.com/ 
    If you have any question, please send your mail to support@aithinker.com 